namespace WebTaskManager
{
    partial class ClusterDiagnosticsDataContext
    {
    }
}
