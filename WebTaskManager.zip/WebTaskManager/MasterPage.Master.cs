﻿using System;
using System.Web.Security;

namespace WebTaskManager
  {
  public partial class MasterPage : System.Web.UI.MasterPage
    {
    protected void Page_Load(object sender, EventArgs e)
      {
      ClusterConnect ccsConnect = ClusterConnect.GetInstance();
      }

    protected void ExitButton_Click(object sender, EventArgs e)
      {
      FormsAuthentication.SignOut();
      FormsAuthentication.RedirectToLoginPage();
      }

    public void RegisterPostbackControl(System.Web.UI.Control control)
    {
      ScriptManagerMasterPage.RegisterPostBackControl(control);
    }
    //------------------------------------------------------------------------------------------------------------------------
    }
  }
