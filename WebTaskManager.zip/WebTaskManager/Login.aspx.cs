﻿using System;
using System.IO;
using System.Web.Security;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using WebTaskManager.FileManager;

namespace WebTaskManager
{
  public partial class Login : System.Web.UI.Page
  {
    //------------------------------------------------------------------------------------------------------------------------
    protected void Page_Load(object sender, EventArgs e)
    {
      FormsAuthentication.SignOut();
      UsernameText.Focus();

      ClusterConnect cluster_connect = ClusterConnect.GetInstance();
      try
      {
        cluster_connect.Connect();
      }
      catch (System.Exception ex)
      {
        LegendStatus.Text = ex.Message;
        return;
      }
    }
    //------------------------------------------------------------------------------------------------------------------------
    protected void Login_Click(object sender, EventArgs e)
    {
      Page.Validate();
      if (!Page.IsValid)
        return;
      if (Membership.ValidateUser(UsernameText.Text, PasswordText.Text) == true)
      {
        ClusterConnect cluster_connect = ClusterConnect.GetInstance();
        Session["username"] = UsernameText.Text;
        Session["password"] = PasswordText.Text;
        Session["workdir"] = @"\\" + cluster_connect.GetClusterAdress() + "\\Userdata\\" + UsernameText.Text + "\\";
        FileSystemManager.SetRootPath(@"\\" + cluster_connect.GetClusterAdress() + "\\Userdata\\" + UsernameText.Text + "\\");
        FileSystemManager.UploadFolder = FileSystemManager.GetRootPath();
        FormsAuthentication.RedirectFromLoginPage(UsernameText.Text, false);
      }
      else
      {
        LegendStatus.Text = "Неправильне ім'я користувача або пароль!";
      }
    }

    //private void AuthentificateClient()
    //{
    //  IPAddress ipAddress = Dns.GetHostAddresses("hpc.univ.kiev.ua")[0];
    //  IPEndPoint remoteEP = new IPEndPoint(ipAddress, 5970);
    //  TcpClient client = new TcpClient();
    //  client.Connect(remoteEP);

    //  NetworkStream clientStream = client.GetStream();
    //  NegotiateStream authStream = new NegotiateStream(clientStream);
    //  authStream.AuthenticateAsClient(new NetworkCredential("administrator", "P5bj7kq", "HPC"), "hpc.univ.kiev.ua");
    //}
    //------------------------------------------------------------------------------------------------------------------------
  }
}
