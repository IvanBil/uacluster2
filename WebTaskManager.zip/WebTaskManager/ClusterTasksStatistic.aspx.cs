﻿using System;

namespace WebTaskManager
  {
  public partial class ClusterTasksStatistic : System.Web.UI.Page
    {
    //------------------------------------------------------------------------------------------------------------------------
    protected void Page_Load(object sender, EventArgs e)
      {
      ClusterConnect cluster_connect = ClusterConnect.GetInstance();
      if (cluster_connect.isConnected == false)
        {
        try
          {
          cluster_connect.Connect();
          }
        catch (System.Exception)
          {
          return;
          }
        }
      }
    //------------------------------------------------------------------------------------------------------------------------
    }
  }
