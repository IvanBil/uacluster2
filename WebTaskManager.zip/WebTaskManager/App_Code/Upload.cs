// According to http://msdn2.microsoft.com/en-us/library/system.web.httppostedfile.aspx
// "Files are uploaded in MIME multipart/form-data format. 
// By default, all requests, including form fields and uploaded files, 
// larger than 256 KB are buffered to disk, rather than held in server memory."
// So we can use an HttpHandler to handle uploaded files and not have to worry
// about the server recycling the request do to low memory. 
// don't forget to increase the MaxRequestLength in the web.config.
// If you server is still giving errors, then something else is wrong.
// I've uploaded a 1.3 gig file without any problems. One thing to note, 
// when the SaveAs function is called, it takes time for the server to 
// save the file. The larger the file, the longer it takes.
// So if a progress bar is used in the upload, it may read 100%, but the upload won't
// be complete until the file is saved.  So it may look like it is stalled, but it
// is not.

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.SessionState;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

/// <summary>
/// Upload handler for uploading files.
/// </summary>
namespace WebTaskManager
  {
  public class Upload : IHttpHandler, IRequiresSessionState
    {
    public Upload()
      {
      }

    #region IHttpHandler Members

    public bool IsReusable
      {
      get { return true; }
      }

    public void ProcessRequest(HttpContext context)
      {
      ClusterConnect cluster_connect = ClusterConnect.GetInstance();
      // Specify the path on the server to save the uploaded file to.
	string uploadPath = context.Request.QueryString["workdir"];

      // loop through all the uploaded files
      for (int j = 0; j < context.Request.Files.Count; j++)
        {
        // get the current file
        HttpPostedFile uploadFile = context.Request.Files[j];
        // if there was a file uploded
        if (uploadFile.ContentLength > 0)
          {
          uploadFile.SaveAs(Path.Combine(uploadPath, uploadFile.FileName));
          }
        }
      // Used as a fix for a bug in mac flash player that makes the 
      // onComplete event not fire
      HttpContext.Current.Response.Write(" ");
      }

    #endregion
    }
  }