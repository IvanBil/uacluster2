﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace WebTaskManager
  {
  public class ComputeClusterDiagnostics
    {
    //------------------------------------------------------------------------------------------------------------------------
    public ComputeClusterDiagnostics()
      {
      DB_Linq = new ClusterDiagnosticsDataContext();
      }
    //------------------------------------------------------------------------------------------------------------------------
    public static ComputeClusterDiagnostics GetInstance()
      {
      if (m_compute_diagnostics == null)
        {
        m_compute_diagnostics = new ComputeClusterDiagnostics();
        }
      return m_compute_diagnostics;
      }
    //------------------------------------------------------------------------------------------------------------------------
    public List<NodeDiagnostics> GetNodeDiagnostcisList(DateTime i_date_from, DateTime i_date_to, int i_count)
      {
      List<NodeDiagnostics> nodes_list;
      nodes_list = (from diag in DB_Linq.ClusterDiagnostics
                       where diag.Time > i_date_from
                       where diag.Time < i_date_to
                       group diag by diag.NodeName into nodes
                       select new NodeDiagnostics(nodes.FirstOrDefault().NodeName)).ToList();

      TimeSpan time_step = new TimeSpan((i_date_to.Ticks - i_date_from.Ticks) / i_count);
      DateTime date_to = i_date_from;
      date_to = date_to.Add(time_step);
      for (int i = 0; i < i_count; ++i)
        {
        var nodes_diag = from diag in DB_Linq.ClusterDiagnostics
                         where diag.Time > i_date_from
                         where diag.Time < date_to
                         group diag by diag.NodeName into nodes
                         select new
                         {
                           name = nodes.FirstOrDefault().NodeName,
                           memory_usage = nodes.Sum(m => m.MemoryUsage) / nodes.Select(p => p.NodeName).Count() / 1024 / 1024,
                           proc_usage = nodes.Sum(p => p.ProcessorUsage) / nodes.Select(p => p.NodeName).Count(),
                         };

        NodeDiagnostics node_diag;
        if (nodes_diag.Count() == 0)
          {
          foreach (NodeDiagnostics node in nodes_list)
            {
            node.MemoryUsageArray.Add(0);
            node.ProcUsageArray.Add(0);
            }
          }
        else
          {
          foreach (var node in nodes_diag)
            {
            node_diag = nodes_list.Find(p => p.NodeName == node.name);
            if (node_diag != null)
              {
              node_diag.MemoryUsageArray.Add(node.memory_usage);
              node_diag.ProcUsageArray.Add(node.proc_usage);
              }
            }
          }
        i_date_from = i_date_from.Add(time_step);
        date_to = date_to.Add(time_step);
        }
      return nodes_list;
      }
    //------------------------------------------------------------------------------------------------------------------------
    public List<NodeDiagnostics> GetNodeDiagnostcisList(DateTime i_date_from, DateTime i_date_to)
      {
      List<NodeDiagnostics> nodes_list;
      nodes_list = (from diag in DB_Linq.ClusterDiagnostics
                    where diag.Time > i_date_from
                    where diag.Time < i_date_to
                    group diag by diag.NodeName into nodes
                    select new NodeDiagnostics(nodes.FirstOrDefault().NodeName)).ToList();

        var nodes_diag = from diag in DB_Linq.ClusterDiagnostics
                         where diag.Time > i_date_from
                         where diag.Time < i_date_to
                         group diag by diag.NodeName into nodes
                         select nodes;

        NodeDiagnostics node_diag;
        foreach (var node in nodes_diag)
          {
          node_diag = nodes_list.Find(p => p.NodeName == node.FirstOrDefault().NodeName);
          if (node_diag != null)
            {
            foreach (var n in node)
              {
              node_diag.MemoryUsageArray.Add(n.MemoryUsage/1024/1024);
              node_diag.ProcUsageArray.Add(n.ProcessorUsage);
              }
            }
          }
        return nodes_list;
      }
    //------------------------------------------------------------------------------------------------------------------------
    private static ComputeClusterDiagnostics m_compute_diagnostics;
    public ClusterDiagnosticsDataContext DB_Linq { get; set; }
    //------------------------------------------------------------------------------------------------------------------------
    }
  }
