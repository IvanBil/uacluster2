﻿using System.Collections;
using System.Runtime;
using System.Reflection;
using System.Collections.Generic;
using System.Configuration;
using Microsoft.Hpc.Scheduler;

//store cluster's settings
namespace WebTaskManager
  {
  public class ClusterConnect
    {
    //---------------------------------------------------------------------------------
    public void Connect()
      {
      _clusterAdress = ConfigurationSettings.AppSettings["HeadNodeName"];
      _cluster = new Scheduler();
      
      _cluster.Connect(_clusterAdress);
      _isConnected = true;
      List<int> lst = new List<int>();
      }

    //---------------------------------------------------------------------------------
    public ISchedulerCollection GetJobsList()
      {
      return _cluster.GetJobList(new FilterCollection(), new SortCollection());
      }
    //---------------------------------------------------------------------------------
    public static ClusterConnect GetInstance()
      {
      if (_settings == null)
        _settings = new ClusterConnect();
      return _settings;
      }
    //---------------------------------------------------------------------------------
    public string GetClusterAdress()
      {
      return _clusterAdress;
      }
    //---------------------------------------------------------------------------------
    public bool isConnected
      {
      get { return _isConnected; }
      set { _isConnected = value; }
      }
    //--------------------------------------------------------------------------------
  
    public Scheduler cluster
      {
      get { return _cluster; }
      set { _cluster = value; }
      }
    //--------------------------------------------------------------------------------
 
    private bool _isConnected = false;
    static ClusterConnect _settings;
    private Scheduler _cluster;
    private static string _clusterAdress;

    }
  }
