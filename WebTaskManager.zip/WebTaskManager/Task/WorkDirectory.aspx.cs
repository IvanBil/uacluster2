﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.Services;
using System.Web.UI.WebControls;

using WebTaskManager.FileManager;

namespace WebTaskManager
  {
  public partial class WorkDirectory : System.Web.UI.Page
    {
    //---------------------------------------------------------------------------------
    protected void Page_Load(object sender, EventArgs e)
      {
        if (!User.Identity.IsAuthenticated)
        {
          FormsAuthentication.RedirectToLoginPage();
          return;
        }

      (this.Master as MasterPage).RegisterPostbackControl(btnSave);
      lblErrors.Text = "";
      if (!IsPostBack)
        {
          BindGrid();
        }
      }
    //---------------------------------------------------------------------------------
    private void _DownloadFiles(string path)
      {
        if (Directory.Exists(path))
        {
          //HttpContext.Current.Response.AppendHeader("Content-Disposition:", "attachment;");
          foreach (FileSystemItem item in FileSystemManager.GetAllFiles(path))
          {
            try
            {
              HttpContext.Current.Response.ContentType = "application/octet-stream";
              HttpContext.Current.Response.Clear();
              HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=" + System.IO.Path.GetFileName(item.FullName) + ";");
              HttpContext.Current.Response.WriteFile(item.FullName);
              HttpContext.Current.Response.TransmitFile(item.FullName);
              HttpContext.Current.Response.End();
            }
            catch (Exception ex)
            {
              throw (ex);
            }
          }
        }
        try
        {
          HttpContext.Current.Response.ContentType = "application/octet-stream";
          HttpContext.Current.Response.Clear();
          HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=" + System.IO.Path.GetFileName(path));
          HttpContext.Current.Response.WriteFile(path);
          HttpContext.Current.Response.TransmitFile(path);
          HttpContext.Current.Response.End();
        }
        catch (Exception ex)
        {
          throw (ex);
        }
      }
    //---------------------------------------------------------------------------------
    public void btnSave_Click(object sender, EventArgs e)
      {
        foreach (GridViewRow row in GridView1.Rows)
        {
          if (row.RowType == DataControlRowType.DataRow)
          {
            CheckBox cb = (CheckBox)row.Cells[0].FindControl("CheckBox1");
            if (cb.Checked)
            {
              LinkButton lb = (LinkButton)row.Cells[1].FindControl("LinkButton1");
              if (Directory.Exists(lb.CommandArgument))
              {
                lblErrors.Text = "Зберегти можна лише один файл";
              }
              else
              {
                _DownloadFiles(lb.CommandArgument);
              }
            }
          }
        }
      }

    [WebMethod]
    public static FileSystemItem GetItemInfo(string path)
      {
      return FileSystemManager.GetItemInfo(path);
      }

    private void BindGrid()
      {
      List<FileSystemItem> list = FileSystemManager.GetItems();
      GridView1.DataSource = list;
      GridView1.DataBind();
      lblCurrentPath.Text = FileSystemManager.GetRootPath();
      }

    private void BindGrid(string path)
      {
      List<FileSystemItem> list = FileSystemManager.GetItems(path);
      GridView1.DataSource = list;
      GridView1.DataBind();
      lblCurrentPath.Text = path;
      }

    protected void btnDelete_Click(object sender, EventArgs e)
      {
      foreach (GridViewRow row in GridView1.Rows)
        {
        if (row.RowType == DataControlRowType.DataRow)
          {
          CheckBox cb = (CheckBox)row.Cells[0].FindControl("CheckBox1");
          if (cb.Checked)
            {
            LinkButton lb = (LinkButton)row.Cells[1].FindControl("LinkButton1");
            if (Directory.Exists(lb.CommandArgument))
              {
              FileSystemManager.DeleteFolder(lb.CommandArgument);
              }
            else
              {
              FileSystemManager.DeleteFile(lb.CommandArgument);
              }
            }
          }
        }
      BindGrid(lblCurrentPath.Text);
      }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
      {
      if (e.Row.RowType == DataControlRowType.Header)
        {
        CheckBox cb = (CheckBox)e.Row.Cells[0].FindControl("chkHeader");
        cb.Attributes.Add("onclick", "FileManager.ToggleSelectionForAllItems(event);");
        }
      if (e.Row.RowType == DataControlRowType.DataRow)
        {
        CheckBox cb = (CheckBox)e.Row.Cells[0].FindControl("CheckBox1");
        cb.Attributes.Add("onclick", "FileManager.UnselectHeaderCheckBox(event);");

        LinkButton lb = (LinkButton)e.Row.Cells[1].FindControl("LinkButton1");
        }
      }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
      {
        if (Directory.Exists(e.CommandArgument.ToString()))
        {
        BindGrid(e.CommandArgument.ToString());
        FileSystemManager.UploadFolder = e.CommandArgument.ToString();
        }
      }

    protected void btnCreate_Click(object sender, EventArgs e)
      {
      FileSystemManager.CreateFolder(TextBox2.Text, lblCurrentPath.Text);
      BindGrid(lblCurrentPath.Text);
      }

    protected void btnUpload_Click(object sender, EventArgs e)
      {
        FileSystemManager.UploadFolder = lblCurrentPath.Text;
        Response.Redirect("SendFiles.aspx");
      }

    protected void btnCut_Click(object sender, EventArgs e)
      {
      List<string> items = new List<string>();
      foreach (GridViewRow row in GridView1.Rows)
        {
        if (row.RowType == DataControlRowType.DataRow)
          {
          CheckBox cb = (CheckBox)row.Cells[0].FindControl("CheckBox1");
          if (cb.Checked)
            {
            LinkButton lb = (LinkButton)row.Cells[1].FindControl("LinkButton1");
            items.Add(lb.CommandArgument);
            }
          }
        }
      ViewState["clipboard"] = items;
      ViewState["action"] = "cut";
      }

    protected void btnPaste_Click(object sender, EventArgs e)
      {
      if (ViewState["clipboard"] != null)
        {
        if (ViewState["action"].ToString() == "cut")
          {
          List<string> items = (List<string>)ViewState["clipboard"];
          foreach (string s in items)
            {
            if (Directory.Exists(s))
              {
              Directory.Move(s, lblCurrentPath.Text + s.Substring(s.LastIndexOf("\\")));
              }
            else
              {
              File.Move(s, lblCurrentPath.Text + "\\" + Path.GetFileName(s));
              }
            }
          }
        else
          {
          List<string> items = (List<string>)ViewState["clipboard"];
          foreach (string s in items)
            {
            if (Directory.Exists(s))
              {
              DirectoryInfo di = new DirectoryInfo(s);
              FileSystemManager.CopyFolder(s, lblCurrentPath.Text + "\\" + di.Name);
              }
            else
              {
              File.Copy(s, lblCurrentPath.Text + "\\" + Path.GetFileName(s));
              }
            }
          }
        }
      ViewState["clipboard"] = null;
      ViewState["action"] = null;
      BindGrid(lblCurrentPath.Text);
      }

    protected void btnCopy_Click(object sender, EventArgs e)
      {
      List<string> items = new List<string>();
      foreach (GridViewRow row in GridView1.Rows)
        {
        if (row.RowType == DataControlRowType.DataRow)
          {
          CheckBox cb = (CheckBox)row.Cells[0].FindControl("CheckBox1");
          if (cb.Checked)
            {
            LinkButton lb = (LinkButton)row.Cells[1].FindControl("LinkButton1");
            items.Add(lb.CommandArgument);
            }
          }
        }
      ViewState["clipboard"] = items;
      ViewState["action"] = "copy";
      }

    protected void btnRename_Click(object sender, EventArgs e)
      {
      string src = "";
      string dest = "";
      foreach (GridViewRow row in GridView1.Rows)
        {
        if (row.RowType == DataControlRowType.DataRow)
          {
          CheckBox cb = (CheckBox)row.Cells[0].FindControl("CheckBox1");
          if (cb.Checked)
            {
            LinkButton lb = (LinkButton)row.Cells[1].FindControl("LinkButton1");
            src = lb.CommandArgument;
            }
          }
        }
      dest = src.Substring(0, src.LastIndexOf('\\'));
      dest = dest + "\\" + TextBox3.Text;
      if (Directory.Exists(src))
        {
        FileSystemManager.MoveFolder(src, dest);
        }
      else
        {
        FileSystemManager.MoveFile(src, dest);
        }
      BindGrid(lblCurrentPath.Text);
      }

    protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
      {
      CheckBox cbHeader = (CheckBox)sender;
      foreach (GridViewRow row in GridView1.Rows)
        {
        if (row.RowType == DataControlRowType.DataRow)
          {
          CheckBox cb = (CheckBox)row.Cells[0].FindControl("CheckBox1");
          cb.Checked = cbHeader.Checked;
          }
        }
      }

    //---------------------------------------------------------------------------------
    }
  }
