﻿using System;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI.WebControls;
using Microsoft.Hpc.Scheduler;
using Microsoft.Hpc.Scheduler.Properties;

namespace WebTaskManager.Task
{
  public partial class AddJob : System.Web.UI.Page
  {
    #region Events
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!User.Identity.IsAuthenticated)
      {
        FormsAuthentication.RedirectToLoginPage();
        return;
      }
      _SetupControls();
    }

    protected void BtnAddTask_Click(object sender, EventArgs e)
    {
      MinRangeValidator.Validate();
      if ((MinRangeValidator.IsValid == true) && (MinText.Text != ""))
        MaxRangeValidator.MinimumValue = MinText.Text;
      else
        return;
      MaxRangeValidator.Validate();
      if ((MaxRangeValidator.IsValid == true) && (int.Parse(MaxText.Text) >= int.Parse(MinText.Text)))
        _AddTask();
      else
        return;
    }

    protected void OnRawDeleted(object sender, System.Web.UI.WebControls.GridViewDeleteEventArgs e)
    {
      AddTaskDS.GetInstance().DeleteTask(e.RowIndex);
      gridtable.DataBind();
    }

    protected void ChooseNodes_Click(object sender, EventArgs e)
    {
    }

    protected void AcceptColumnsButton_Click(object sender, EventArgs e)
    {
      if (m_task == null)
        m_task = m_job.CreateTask();
      m_task.RequiredNodes = new StringCollection();
      for (int i = 0; i < NodesList.Items.Count; ++i)
      {
        if (NodesList.Items[i].Selected == true)
        {
          if (m_task.RequiredNodes.Count < 1)
            m_task.RequiredNodes.Add(NodesList.Items[i].Text);
          else
            m_task.RequiredNodes.Add("," + NodesList.Items[i].Text);
        }
      }
    }
    protected void ddlResourceType_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (ddlResourceType.SelectedValue == JobUnitType.Core.ToString())
      {
        _currentJobUnitType = JobUnitType.Core;
      }
      else if (ddlResourceType.SelectedValue == JobUnitType.Node.ToString())
        _currentJobUnitType = JobUnitType.Node;
      else if (ddlResourceType.SelectedValue == JobUnitType.Socket.ToString())
        _currentJobUnitType = JobUnitType.Socket;
    }

    protected void ddlPriority_IndexChanged(object sender, EventArgs e)
    {
      if (ddlPriority.SelectedValue == JobPriority.Lowest.ToString())
      {
        _CurrentPriority = JobPriority.Lowest;
      }
      else if (ddlPriority.SelectedValue == JobPriority.Normal.ToString())
        _CurrentPriority = JobPriority.Normal;
      else if (ddlPriority.SelectedValue == JobPriority.BelowNormal.ToString())
        _CurrentPriority = JobPriority.BelowNormal;
      else if (ddlPriority.SelectedValue == JobPriority.AboveNormal.ToString())
        _CurrentPriority = JobPriority.AboveNormal;
      else if (ddlPriority.SelectedValue == JobPriority.Highest.ToString())
        _CurrentPriority = JobPriority.Highest;
    }

    protected void ddlTemplate_IndexChanged(object sender, EventArgs  e)
    {
      _CurrentTemplate = ddlTemplate.SelectedValue;
    }
    #endregion

    #region Wizard Events
    protected void wzAbbJob_NextButtonClick(object sender, WizardNavigationEventArgs e)
    {
      _AcceptJobInfo();
    }

    protected void wzAddJob_CancelButtonClick(object sender, EventArgs e)
    {
      _ClearSession();
      Response.Redirect("~/Task/ShowTasks.aspx");
    }

    protected void wzAddJob_FinishButtonClick(object sender, WizardNavigationEventArgs e)
    {
      _SendJobToCluster();
      _ClearSession();
      HttpResponse response = this.Response;
      response.Redirect("~/Task/ShowTasks.aspx");
    }
    #endregion

    #region Private methods
    private void _ClearSession()
    {
      Session.Remove("AbbJob_CurrentJob");
      Session.Remove("AbbJob_CurrentTask");
      Session.Remove("AbbJob_CurrentJobType");
    }

    private void _AcceptJobInfo()
    {
      int minResource;
      int maxResource;

      m_job.Name = JobNameText.Text;
      m_job.Project = ProjectNameText.Text;
      //Priority
      if (ddlPriority.SelectedValue.Equals(JobPriority.Lowest.ToString()))
        m_job.Priority = JobPriority.Lowest;
      else if (ddlPriority.SelectedValue.Equals(JobPriority.BelowNormal.ToString()))
        m_job.Priority = JobPriority.BelowNormal;
      else if (ddlPriority.SelectedValue.Equals(JobPriority.Normal.ToString()))
        m_job.Priority = JobPriority.Normal;
      else if (ddlPriority.SelectedValue.Equals(JobPriority.AboveNormal.ToString()))
        m_job.Priority = JobPriority.AboveNormal;
      else if (ddlPriority.SelectedValue.Equals(JobPriority.Highest.ToString()))
        m_job.Priority = JobPriority.Highest;
      //Resource type
      if (ddlResourceType.SelectedValue.Equals(JobUnitType.Core.ToString()))
        m_job.UnitType = JobUnitType.Core;
      else if (ddlResourceType.SelectedValue.Equals(JobUnitType.Node.ToString()))
        m_job.UnitType = JobUnitType.Node;
      else if (ddlResourceType.SelectedValue.Equals(JobUnitType.Socket))
        m_job.UnitType = JobUnitType.Socket;

      _CurrentPriority = m_job.Priority;
      _CurrentTemplate = m_job.JobTemplate;
      _currentJobUnitType = m_job.UnitType;
      if (!string.IsNullOrEmpty(JobMinText.Text) && int.TryParse(JobMinText.Text, out minResource))
      {
        switch (_currentJobUnitType)
        {
          case JobUnitType.Core:
            m_job.MinimumNumberOfCores = minResource;
            break;
          case JobUnitType.Node:
            m_job.MinimumNumberOfNodes = minResource;
            break;
          case JobUnitType.Socket:
            m_job.MinimumNumberOfSockets = minResource;
            break;
        }
      }

      if (!string.IsNullOrEmpty(JobMaxText.Text) && int.TryParse(JobMaxText.Text, out maxResource))
      {
        switch (_currentJobUnitType)
        {
          case JobUnitType.Core:
            m_job.MaximumNumberOfCores = maxResource;
            break;
          case JobUnitType.Node:
            m_job.MaximumNumberOfNodes = maxResource;
            break;
          case JobUnitType.Socket:
            m_job.MaximumNumberOfSockets = maxResource;
            break;
        }
      }

      m_job.IsExclusive = chbExclusive.Checked;
      m_job.RunUntilCanceled = chbRunTime.Checked;
      m_job.FailOnTaskFailure = chbFail.Checked;

      if (chbTimeLimit.Checked)
      {
        int days;
        int hours;
        int minutes;
        if (int.TryParse(txtDays.Text, out days) && int.TryParse(txtHours.Text, out hours) && int.TryParse(txtMinutes.Text, out minutes))
        {
          _TimeLimit = new TimeSpan(days, hours, minutes, 0);
        }
      }
    }

    private void _SetupControls()
    {
      ClusterConnect cluster_connect = ClusterConnect.GetInstance();
      if (cluster_connect.isConnected == false)
        cluster_connect.Connect();
      if (m_job == null)
        m_job = cluster_connect.cluster.CreateJob();

      ISchedulerCounters cluster_counter = cluster_connect.cluster.GetCounters();
      MaxRangeValidator.MaximumValue = (cluster_counter.TotalCores - cluster_counter.BusyCores).ToString();
      JobMaxRangeValidator.MaximumValue = (cluster_counter.TotalCores - cluster_counter.BusyCores).ToString();

      JobMinText.Items.Clear();
      JobMaxText.Items.Clear();
      MinText.Items.Clear();
      MaxText.Items.Clear();

      int proc_count = 1;
        if (ddlResourceType.SelectedValue == JobUnitType.Core.ToString())
            proc_count = cluster_counter.TotalCores - cluster_counter.BusyCores - cluster_counter.OfflineCores;
        if (ddlResourceType.SelectedValue == JobUnitType.Node.ToString())
            proc_count = cluster_counter.TotalNodes - cluster_counter.OfflineNodes - cluster_counter.UnreachableNodes;
        if (ddlResourceType.SelectedValue == JobUnitType.Socket.ToString())
            proc_count = cluster_counter.TotalSockets;

        for (int i = 0; i < proc_count; ++i)
      {
        JobMinText.Items.Add((i + 1).ToString());
        JobMaxText.Items.Add((i + 1).ToString());
        MinText.Items.Add((i + 1).ToString());
        MaxText.Items.Add((i + 1).ToString());
      }
      if (JobMinText.Text == "")
        JobMinText.Text = "1";
      if (JobMaxText.Text == "")
        JobMaxText.Text = "1";
      if (MinText.Text == "")
        MinText.Text = "1";
      if (MaxText.Text == "")
        MaxText.Text = "1";

      if (IsPostBack == false)
        _UpdateNodesList();

      //Priority
      string selectedPriority = ddlPriority.SelectedValue;
      string selectedUnitType = ddlResourceType.SelectedValue;
      string selectedTemplate = ddlTemplate.SelectedValue;
      ddlPriority.Items.Clear();
      ddlPriority.Items.Add(new ListItem("Мінімальний", JobPriority.Lowest.ToString()));
      ddlPriority.Items.Add(new ListItem("Нижче нормального", JobPriority.BelowNormal.ToString()));
      ddlPriority.Items.Add(new ListItem("Нормальний", JobPriority.Normal.ToString()));
      ddlPriority.Items.Add(new ListItem("Вище нормального", JobPriority.AboveNormal.ToString()));
      ddlPriority.Items.Add(new ListItem("Найвищий", JobPriority.Highest.ToString()));

      if (!String.IsNullOrEmpty(selectedPriority))
        ddlPriority.SelectedValue = selectedPriority;
      //Resource Type
      ddlResourceType.Items.Clear();
      ddlResourceType.Items.Add(new ListItem("Ядро", JobUnitType.Core.ToString()));
      ddlResourceType.Items.Add(new ListItem("Вузол", JobUnitType.Node.ToString()));
      ddlResourceType.Items.Add(new ListItem("Сокет", JobUnitType.Socket.ToString()));
      if (!String.IsNullOrEmpty(selectedUnitType))
        ddlResourceType.SelectedValue = selectedUnitType;

      JobMinRangeValidator.Validate();
      if ((JobMinRangeValidator.IsValid == true) && (JobMinText.Text != ""))
        JobMaxRangeValidator.MinimumValue = JobMinText.Text;

      JobMaxRangeValidator.Validate();
      if (JobMaxRangeValidator.IsValid == true)
      {
        MaxRangeValidator.MaximumValue = JobMaxText.Text;
        MinRangeValidator.MaximumValue = JobMaxText.Text;
      }

      ddlTemplate.Items.Clear();
      foreach (string str in cluster_connect.cluster.GetJobTemplateList())
      {
        ddlTemplate.Items.Add(new ListItem(str, str));
      }

          if (!String.IsNullOrEmpty(selectedTemplate))
          {
              ddlTemplate.SelectedValue = selectedTemplate;
              m_job.SetJobTemplate(selectedTemplate);
              if (_CurrentTemplate != selectedTemplate)
              {
                  _CurrentTemplate = selectedTemplate;
                  _InitializeFromTemplate();
              }
      }
    }

    private void _UpdateValidCountOfProcessors()
    {
      JobMinRangeValidator.Validate();
      if ((JobMinRangeValidator.IsValid == true) && (JobMinText.Text != ""))
        JobMaxRangeValidator.MinimumValue = JobMinText.Text;
      else
        return;
      JobMaxRangeValidator.Validate();
      if (JobMaxRangeValidator.IsValid == true)
      {
        MaxRangeValidator.MaximumValue = JobMaxText.Text;
        MinRangeValidator.MaximumValue = JobMaxText.Text;
      }
      else
        return;
    }

    private void _AddTask()
    {
      if (String.IsNullOrEmpty(CommandLineText.Text))
        return;

      int minResource;
      int maxResource;

      ClusterConnect cluster_connect = ClusterConnect.GetInstance();
      if (m_task == null && m_job != null)
        m_task = m_job.CreateTask();

      m_task.WorkDirectory = (string)Session["workdir"];//default work directory
      m_task.Name = TaskNameText.Text.Replace("{dir}", (string)Session["workdir"]);
      m_task.CommandLine = CommandLineText.Text.Replace("{dir}", (string)Session["workdir"]);

      if (!String.IsNullOrEmpty(OutText.Text))
        m_task.StdOutFilePath = OutText.Text.Replace("{dir}", (string)Session["workdir"]);
      if (!String.IsNullOrEmpty(ErrorText.Text))
        m_task.StdErrFilePath = ErrorText.Text.Replace("{dir}", (string)Session["workdir"]);
      if (!String.IsNullOrEmpty(InputText.Text))
        m_task.StdInFilePath = InputText.Text.Replace("{dir}", (string)Session["workdir"]);

      if (!string.IsNullOrEmpty(MinText.Text) && int.TryParse(MinText.Text, out minResource))
      {
        switch (_currentJobUnitType)
        {
          case JobUnitType.Core:
            m_task.MinimumNumberOfCores = minResource;
            break;
          case JobUnitType.Node:
            m_task.MinimumNumberOfNodes = minResource;
            break;
          case JobUnitType.Socket:
            m_task.MinimumNumberOfSockets = minResource;
            break;
        }
      }

      if (!string.IsNullOrEmpty(MaxText.Text) && int.TryParse(MaxText.Text, out maxResource))
      {
        switch (_currentJobUnitType)
        {
          case JobUnitType.Core:
            m_task.MaximumNumberOfCores = maxResource;
            break;
          case JobUnitType.Node:
            m_task.MaximumNumberOfNodes = maxResource;
            break;
          case JobUnitType.Socket:
            m_task.MaximumNumberOfSockets = maxResource;
            break;
        }
      }

      m_job.AddTask(m_task);

      ////add task to tasks list
      _AddTaskToList(m_task);

      m_task = null;

      foreach (ListItem item in NodesList.Items)
        item.Selected = false;

      CommandLineText.Text = "";
      TaskNameText.Text = "";
      ErrorText.Text = "";
      InputText.Text = "";
      OutText.Text = "";
    }

    private void _AddTaskToList(ISchedulerTask i_task)
    {
      AddTaskDS.GetInstance().AddItem(m_task);
      gridtable.DataBind();
    }

    private void _UpdateNodesList()
    {
      NodesList.Items.Clear();
      ClusterConnect cluster_connect = ClusterConnect.GetInstance();
      IEnumerator nodes_enum;
      try
      {
        nodes_enum = cluster_connect.cluster.GetNodeList(null, null).GetEnumerator();
      }
      catch (Exception)
      {
        cluster_connect.Connect();
        nodes_enum = cluster_connect.cluster.GetNodeList(null, null).GetEnumerator();
      }
      nodes_enum.Reset();
      while (nodes_enum.MoveNext())
      {
        if (((ISchedulerNode)nodes_enum.Current).State == NodeState.Online)
          NodesList.Items.Add(((ISchedulerNode)nodes_enum.Current).Name);
      }
    }

    private void _SendJobToCluster()
    {
      ClusterConnect cluster_connect = ClusterConnect.GetInstance();
      m_job.Name = JobNameText.Text;
      m_job.Project = ProjectNameText.Text;
      switch (_currentJobUnitType)
      {
        case JobUnitType.Core:
          m_job.MinimumNumberOfCores = int.Parse(JobMinText.Text);
          m_job.MaximumNumberOfCores = int.Parse(JobMaxText.Text);
          break;
        case JobUnitType.Node:
          m_job.MinimumNumberOfNodes = int.Parse(JobMinText.Text);
          m_job.MaximumNumberOfNodes = int.Parse(JobMaxText.Text);
          break;
        case JobUnitType.Socket:
          m_job.MinimumNumberOfSockets = int.Parse(JobMinText.Text);
          m_job.MaximumNumberOfSockets = int.Parse(JobMaxText.Text);
          break;
      }

      cluster_connect.cluster.AddJob(m_job);
      try
      {
        if (cluster_connect.isConnected == false || (string)Session["username"] == null || (string)Session["password"] == null)
          cluster_connect.Connect();
        cluster_connect.cluster.SubmitJob(m_job, (string)Session["username"], (string)Session["password"]);
      }
      catch (Exception)
      {
        return;
      }
      m_job = null;
      AddTaskDS.GetInstance().Clear();
    }

    private void _InitializeFromTemplate()
    {
      ddlPriority.SelectedValue = m_job.Priority.ToString();
      ddlResourceType.SelectedValue = m_job.UnitType.ToString();
      chbExclusive.Checked = m_job.IsExclusive;
      chbRunTime.Checked = m_job.RunUntilCanceled;
      chbTimeLimit.Checked = m_job.HasRuntime;
      chbFail.Checked = m_job.FailOnTaskFailure;
    }
    #endregion

    #region Private members
    private ISchedulerJob m_job
    {
      get
      {
        if (Session["AbbJob_CurrentJob"] == null)
          Session["AbbJob_CurrentJob"] = ClusterConnect.GetInstance().cluster.CreateJob();
        return Session["AbbJob_CurrentJob"] as ISchedulerJob;
      }
      set
      {
        Session["AbbJob_CurrentJob"] = value;
      }
    }
    private ISchedulerTask m_task
    {
      get
      {
        if (Session["AbbJob_CurrentTask"] == null)
          Session["AbbJob_CurrentTask"] = m_job.CreateTask();
        return Session["AbbJob_CurrentTask"] as ISchedulerTask;
      }
      set
      {
        Session["AbbJob_CurrentTask"] = value;
      }
    }
    private JobUnitType _currentJobUnitType
    {
      get
      {
        return (JobUnitType)Session["AbbJob_CurrentJobType"];
      }
      set
      {
        Session["AbbJob_CurrentJobType"] = value;
      }
    }
    private Nullable<TimeSpan> _TimeLimit
    {
      get
      {
        return (Nullable<TimeSpan>)Session["AbbJob_IsTimeLimit"];
      }
      set
      {
        Session["AbbJob_IsTimeLimit"] = value;
      }
    }

    private JobPriority _CurrentPriority
    {
      get
      {
        return (JobPriority)Session["AbbJob_CurrentPriority"];
      }
      set
      {
        Session["AbbJob_CurrentPriority"] = value;
      }

    }

    private string _CurrentTemplate
    {
      get
      {
        return (string)Session["AbbJob_CurrentTemplate"];
      }
      set
      {
        Session["AbbJob_CurrentTemplate"] = value;
      }
    }
    #endregion
  }
}
