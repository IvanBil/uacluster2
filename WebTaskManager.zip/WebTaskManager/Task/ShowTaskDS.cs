﻿using System.Collections.Generic;
using System.ComponentModel;
using Microsoft.Hpc.Scheduler;
using Microsoft.Hpc.Scheduler.Properties;

namespace WebTaskManager.Task
  {
  /// <summary>
  /// /////////////////////////////////////////////////////////////////////////////////
  /// </summary>
  public class ShowTask
    {
    //---------------------------------------------------------------------------------
    public ShowTask(ISchedulerJob i_job)
      {
      m_job_id =          i_job.Id.ToString();
      m_job_name =        i_job.Name;
      m_job_user =        i_job.UserName;
      m_priority =        i_job.Priority.ToString();
      m_status =          i_job.State.ToString();
      m_submit_time =     i_job.SubmitTime.ToString();
      m_start_time =      i_job.StartTime.ToString();
      m_end_time =        i_job.EndTime.ToString();
      m_error_message =   i_job.ErrorMessage;
      m_number_of_procs = i_job.MinimumNumberOfCores.ToString() + " - " + i_job.MaximumNumberOfCores.ToString();

      if ((i_job.State == JobState.Queued) || (i_job.State == JobState.Running))
        m_cancel_button = "X";
      else
        m_cancel_button = "";
      }
    //---------------------------------------------------------------------------------
    public string JobId
      {
      get { return m_job_id; }
      }
    //---------------------------------------------------------------------------------
    public string JobName
      {
      get { return m_job_name; }
      }
    //---------------------------------------------------------------------------------
    public string JobUser
      {
      get { return m_job_user; }
      }
    //---------------------------------------------------------------------------------
    public string Priority
      {
      get { return m_priority; }
      }
    //---------------------------------------------------------------------------------
    public string Status
      {
      get { return m_status; }
      }
    //---------------------------------------------------------------------------------
    public string SubmitTime
      {
      get { return m_submit_time; }
      }
    //---------------------------------------------------------------------------------
    public string StartTime
      {
      get { return m_start_time; }
      }
    //---------------------------------------------------------------------------------
    public string EndTime
      {
      get { return m_end_time; }
      }
    //---------------------------------------------------------------------------------
    public string ErrorMessage
      {
      get { return m_error_message; }
      }
    //---------------------------------------------------------------------------------
    public string NumberOfProcessors
      {
      get { return m_number_of_procs; }
      }
    //---------------------------------------------------------------------------------
    public string CancelButton
      {
      get { return m_cancel_button; }
      }
    //---------------------------------------------------------------------------------

    private string m_job_id;
    private string m_job_name;
    private string m_job_user;
    private string m_priority;
    private string m_status;
    private string m_submit_time;
    private string m_start_time;
    private string m_end_time;
    private string m_error_message;
    private string m_number_of_procs;
    private string m_cancel_button;
    }

  /// <summary>
  /// ////////////////////////////////////////////////////////////////////////////////
  /// </summary>
  /// 
  [DataObject]
  public class ShowTaskDS
    {
    //---------------------------------------------------------------------------------
    public ShowTaskDS()
      {
      }
    //---------------------------------------------------------------------------------
    public static ShowTaskDS GetInstance()
      {
      if (m_show_task_ds == null)
        {
        m_show_task_ds = new ShowTaskDS();
        return m_show_task_ds;
        }
      else
        return m_show_task_ds;
      }
    //---------------------------------------------------------------------------------
    [DataObjectMethod(DataObjectMethodType.Select)]
    public List<ShowTask> GetTasks()
      {
      return m_show_tasks;
      }
    //---------------------------------------------------------------------------------
    public void DeleteTask(int index)
      {
      m_show_tasks.Remove(m_show_tasks[index]);
      }
    //---------------------------------------------------------------------------------
    public void DeleteTask()
      {
      }
    //---------------------------------------------------------------------------------
    public void Clear()
      {
      m_show_tasks.Clear();
      }
    //---------------------------------------------------------------------------------
    public void AddItem(ISchedulerJob i_job)
      {
      m_show_tasks.Insert(0, new ShowTask(i_job));
      }
    //---------------------------------------------------------------------------------

    private static List<ShowTask> m_show_tasks = new List<ShowTask>();
    private static ShowTaskDS m_show_task_ds;

    }
  }
