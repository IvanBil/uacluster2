﻿using System.Collections.Generic;
using System.ComponentModel;
using Microsoft.Hpc.Scheduler;

namespace WebTaskManager.Task
{
  //---------------------------------------------------------------------------------
  public class TaskView
  {
    public TaskView()
    {

    }

    public TaskView(ISchedulerTask i_task)
    {
      m_cmd_line = i_task.CommandLine;
      m_task_name = i_task.Name;
      m_required_nodes = i_task.RequiredNodes;
    }

    public string CommandLine
    {
      get { return m_cmd_line; }
      set { m_cmd_line = value; }
    }

    public string TaskName
    {
      get { return m_task_name; }
    }

    public ISchedulerCollection RequiredNodes
    {
      get { return m_required_nodes; }
    }

    private string m_cmd_line;
    private string m_task_name;
    private IStringCollection m_required_nodes;
  }


  [DataObject]
  public class AddTaskDS
  {
    #region Constructors
    public AddTaskDS()
    {

    }
    #endregion

    #region Public methods
    [DataObjectMethod(DataObjectMethodType.Select)]
    public static List<TaskView> GetTasks()
    {
      if (m_tasks.Count > 0)
        return m_tasks;
      else
      {
        TaskView taskView = new TaskView();
        taskView.CommandLine = "Список задач для поточної роботи пустий";
        m_tasks.Add(taskView);
        return m_tasks;
      }
    }

    public void DeleteTask(int index)
    {
      m_tasks.Remove(m_tasks[index]);
    }

    public void DeleteTask()
    {
    }

    public void AddItem(ISchedulerTask i_task)
    {
      m_tasks.Add(new TaskView(i_task));
    }

    public static AddTaskDS GetInstance()
    {
      if (m_AddTaskDS == null)
        m_AddTaskDS = new AddTaskDS();
      return m_AddTaskDS;
    }

    public void Clear()
    {
      m_tasks.Clear();
    }
    #endregion

    #region Private fields
    private static List<TaskView> m_tasks = new List<TaskView>();
    private static AddTaskDS m_AddTaskDS;
    #endregion
  }
}
