﻿using System;
using System.Web.Security;

using WebTaskManager.FileManager;

namespace WebTaskManager
  {
  public partial class SendFiles : System.Web.UI.Page
    {
    protected void Page_Load(object sender, EventArgs e)
      {
        if (!User.Identity.IsAuthenticated)
        {
          FormsAuthentication.RedirectToLoginPage();
          return;
        }
      string jscript = "function UploadComplete(){" + ClientScript.GetPostBackEventReference(LinkButton1, "") + "};";
      Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "FileCompleteUpload", jscript, true);

      flashUpload.QueryParameters = string.Format("workdir={0}", FileSystemManager.UploadFolder);
      if (FileSystemManager.UploadFolder != FileSystemManager.GetRootPath())
        lblCurrentPathText.Text = FileSystemManager.UploadFolder.Replace(FileSystemManager.GetRootPath(), "");
      else
        lblCurrentPathText.Text = "[Root]";
      }
    //------------------------------------------------------------------------------------------------------------------------
    protected void LinkButton1_Click(object sender, EventArgs e)
      {
        Response.Redirect("WorkDirectory.aspx");
      }
    //------------------------------------------------------------------------------------------------------------------------
    }
  }
