﻿using System;
using System.Collections;
using System.Web.Security;
using System.Web.UI.WebControls;
using Microsoft.Hpc.Scheduler;
using Microsoft.Hpc.Scheduler.Properties;

namespace WebTaskManager.Task
  {
  public partial class ShowTasks : System.Web.UI.Page
    {
    //---------------------------------------------------------------------------------
    protected void Page_Load(object sender, EventArgs e)
      {
      if (!User.Identity.IsAuthenticated)
        {
        FormsAuthentication.RedirectToLoginPage();
        return;
        }
      m_is_cancel_job_column_visible = false;
      _InitializeTaskList();
      }
    //---------------------------------------------------------------------------------
    protected bool _InitializeTaskList()
      {
      ClusterConnect ccs = ClusterConnect.GetInstance();
      IEnumerator jobsList;
      SchedulerJob currentJob;
      if (ccs.isConnected == false)
        {
        try
          {
          ccs.Connect();
          }
        catch
          {
          return false;
          }
        }
      try
        {
        jobsList = ccs.GetJobsList().GetEnumerator();
        }
      catch
        {
        return false;
        }
      jobsList.Reset();
      ShowTaskDS.GetInstance().Clear();
      while (jobsList.MoveNext())
        {
          currentJob = (SchedulerJob)jobsList.Current;
        ShowTaskDS.GetInstance().AddItem(currentJob);
        if ((currentJob.State == JobState.Running) || (currentJob.State == JobState.Queued))
          m_is_cancel_job_column_visible = true;
        }
      if (IsPostBack == false)
        {
        _SetDefaultColumns();
        _UpdateColumnsList();
        }
      else
        ShowTaskGrid.DataBind();
      return true;
      }
    //---------------------------------------------------------------------------------
    protected void _SetDefaultColumns()
      {
      for (int i = 0; i < ShowTaskGrid.Columns.Count; ++i)
        ShowTaskGrid.Columns[i].Visible = true;

      ShowTaskGrid.Columns[0].Visible = false;
      ShowTaskGrid.Columns[3].Visible = false;
      ShowTaskGrid.Columns[5].Visible = false;
      ShowTaskGrid.Columns[8].Visible = false;
      ShowTaskGrid.Columns[9].Visible = false;
      if (m_is_cancel_job_column_visible == false)
        ShowTaskGrid.Columns[10].Visible = false;
      ShowTaskGrid.DataBind();
      }
    //---------------------------------------------------------------------------------
    protected void _UpdateColumnsList()
      {
      for (int i = 0; i < ColumnsList.Items.Count; ++i)
        {
        if (ShowTaskGrid.Columns[i].Visible == true)
          ColumnsList.Items[i].Selected = true;
        else
          ColumnsList.Items[i].Selected = false;
        }
      }
    //---------------------------------------------------------------------------------
    protected void DefaultColumns_Click(object sender, EventArgs e)
      {
      _SetDefaultColumns();
      _UpdateColumnsList();
      }
    //---------------------------------------------------------------------------------
    protected void OnCancelJobClicked(object sender, GridViewCommandEventArgs e)
      {
      if (e.CommandName == "CancelJob")
        {
        int index = Convert.ToInt32(e.CommandArgument);
        MessageLabel.Text = "";
        ClusterConnect ccs = ClusterConnect.GetInstance();

        Label lblJobUser = (Label)ShowTaskGrid.Rows[index].FindControl("lblJobUser");
        string job_user = lblJobUser.Text.Replace(@"HPC\", "");
        if ((string)Session["username"] == job_user)
          {
          try
            {
              Label lblJobID = (Label)ShowTaskGrid.Rows[index].FindControl("lblJobID");
              ccs.cluster.CancelJob(Convert.ToInt32(lblJobID.Text), "Відмінено користувачем " + (string)Session["username"]);
            }
          catch (Exception)
            {
            return;
            }
          }
        else
          MessageLabel.Text = "Ви не можете відміти задачу, яка поставлена іншим користувачем";
        ShowTaskGrid.DataBind();
        this.Page_Load(this, null);
        }
      }
    //---------------------------------------------------------------------------------
    protected void UpdateColumns(object sender, EventArgs e)
      {
      bool is_some_columns_choosed = false;
      for (int i = 0; i < ColumnsList.Items.Count; ++i)
        {
        if (ColumnsList.Items[i].Selected == true)
          {
          ShowTaskGrid.Columns[i].Visible = true;
          if (is_some_columns_choosed == false)
            is_some_columns_choosed = true;
          }
        else
          ShowTaskGrid.Columns[i].Visible = false;
        }
      if (is_some_columns_choosed == false)
        ShowTaskGrid.Visible = false;       //we don't need list of task in this case
      else
        ShowTaskGrid.Visible = true;
      }
    //---------------------------------------------------------------------------------
    private bool m_is_cancel_job_column_visible;
    }
  }
