﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Services;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;

namespace WebTaskManager
  {
  public enum DiagnosticType
     {
     ProcessorTime,
     MemoryUsage
     }
  /// <summary>
  /// This class is store's memory usages and processor times arrays for specified node and for specified period
  /// </summary>
  public class NodeDiagnostics
  {
    //------------------------------------------------------------------------------------------------------------------------
    public NodeDiagnostics()
    {
      MemoryUsageArray = new List<double>();
      ProcUsageArray = new List<double>();
    }
    //------------------------------------------------------------------------------------------------------------------------
    public NodeDiagnostics(string node_name)
    {
      NodeName = node_name;
      MemoryUsageArray = new List<double>();
      ProcUsageArray = new List<double>();
    }
    //------------------------------------------------------------------------------------------------------------------------
    public NodeDiagnostics(string node_name, List<double> i_memory_arr, List<double> i_pro_arr)
    {
      NodeName = node_name;
      MemoryUsageArray = i_memory_arr;
      ProcUsageArray = i_pro_arr;
    }
    //------------------------------------------------------------------------------------------------------------------------
    public string NodeName { set; get; }
    public List<double> MemoryUsageArray { set; get; }
    public List<double> ProcUsageArray { set; get; }
  }
  //------------------------------------------------------------------------------------------------------------------------
  public partial class ClusterPerformance : System.Web.UI.Page
    {
    //------------------------------------------------------------------------------------------------------------------------
    protected void Page_Load(object sender, EventArgs e)
      {
      if (this.IsPostBack == false)
        {
        //Fill dropdown controls for minutes and hours;
        ListItem[] starthours = new ListItem[24];
        ListItem[] endhours = new ListItem[24];
        for (int i = 0; i < 24; ++i)
          {
          starthours[i] = new ListItem(i.ToString(), i.ToString());
          endhours[i] = new ListItem(i.ToString(), i.ToString());
          }
        ListItem[] startminutes = new ListItem[60];
        ListItem[] endminutes = new ListItem[60];
        for (int i = 0; i < 60; ++i)
          {
          startminutes[i] = new ListItem(i.ToString(), i.ToString());
          endminutes[i] = new ListItem(i.ToString(), i.ToString());
          }

        StartHour.Items.AddRange(starthours);
        StartMinute.Items.AddRange(startminutes);

        EndHour.Items.AddRange(endhours);
        EndMinute.Items.AddRange(endminutes);

        //Fill dropdown control for review method (for month, for year, custom TimeSpan) 
        TimeInterval.Items.Add(new ListItem("Графіки за обраний проміжок часу", ((int)0).ToString()));
        TimeInterval.Items.Add(new ListItem("Графіки за поточний місяць", ((int)1).ToString()));
        TimeInterval.Items.Add(new ListItem("Графіки за поточний рік", ((int)2).ToString()));
        TimeInterval.SelectedIndex = 0;
        TimeInterval.Visible = false; //Temporary

        TimeSpan default_span = new TimeSpan(1, 0, 0);
        if ((Session["start time"] == null) || (Session["end time"] == null))
          _CreateGraphicsDateTime(DateTime.Now.Subtract(default_span), DateTime.Now);

        DateStartCalendarExtender.SelectedDate = ((DateTime)Session["start time"]);
        StartHour.SelectedIndex = ((DateTime)Session["start time"]).Hour;
        StartMinute.SelectedIndex = ((DateTime)Session["start time"]).Minute;

        DateEndCalendarExtender.SelectedDate = ((DateTime)Session["end time"]);
        EndHour.SelectedIndex = ((DateTime)Session["end time"]).Hour;
        EndMinute.SelectedIndex = ((DateTime)Session["end time"]).Minute;

        //Get diagnostics for day
        DateTime date_end = ((DateTime)Session["end time"]);
        DateTime date_start = ((DateTime)Session["start time"]);

        _BuildReports(date_start, date_end);
        }
      }
    //------------------------------------------------------------------------------------------------------------------------
    private void _BuildReports(DateTime date_start, DateTime date_end)
      {
      ClusterDiagnosticsDataContext DB_Linq = new ClusterDiagnosticsDataContext();
      List<string> node_names = (from diag in DB_Linq.ClusterDiagnostics
                                 where diag.Time > date_start
                                 where diag.Time < date_end
                                 group diag by diag.NodeName into nodes
                                 select nodes.FirstOrDefault().NodeName).ToList();

      node_names.Sort();
    
      //Clear old graphics if it was exist
      PlaceHolderProcessor.Controls.Clear();
      PlaceHolderMemory.Controls.Clear();

      foreach (string node_name in node_names)
        {
        _CreateReports(node_name, DiagnosticType.ProcessorTime, date_start,date_end);
        _CreateReports(node_name, DiagnosticType.MemoryUsage, date_start, date_end);
        }
      }
    //------------------------------------------------------------------------------------------------------------------------
    private void _CreateReports(string node_name, DiagnosticType type, DateTime date_start, DateTime date_end)
      {
      ReportViewer reportViewer = new ReportViewer();
      reportViewer.Visible = true;
      reportViewer.ShowToolBar = false;
      reportViewer.Height = 300;
      reportViewer.Width = 400;

      ReportDataSource source;
      string proccCommand = "SELECT * FROM dbo.ClusterDiagnostics where Time > '" + _GetDateTimeForSQLQuery(date_start) + "' and Time < '" + _GetDateTimeForSQLQuery(date_end) + "' and nodename='" + node_name + "';";
      string memoryCommand = "SELECT ID, NodeName, Time, ProcessorUsage, Memory=MemoryUsage/1024/1024 FROM dbo.ClusterDiagnostics where Time > '" + _GetDateTimeForSQLQuery(date_start) + "' and Time < '" + _GetDateTimeForSQLQuery(date_end) + "' and nodename='" + node_name + "';";
      switch (type)
        {
        case DiagnosticType.ProcessorTime:
          reportViewer.ID = "ReportViewerProc" + node_name;
          PlaceHolderProcessor.Controls.Add(reportViewer);

          source = new ReportDataSource("DataSet1_ClusterDiagnostics", ConnectToData(GetConnectionString(), proccCommand));
          reportViewer.LocalReport.DataSources.Add(source);
          reportViewer.LocalReport.ReportPath = @".\Reports\ReportProcessorUsage" + node_name + ".rdlc"; // Create report from .rdlc file
          break;

        case DiagnosticType.MemoryUsage:
          reportViewer.ID = "ReportViewerMemory" + node_name;
          PlaceHolderMemory.Controls.Add(reportViewer);

          source = new ReportDataSource("DataSet1_ClusterDiagnostics", ConnectToData(GetConnectionString(), memoryCommand));
          reportViewer.LocalReport.DataSources.Add(source);
          reportViewer.LocalReport.ReportPath = @".\Reports\ReportMemoryUsage" + node_name + ".rdlc";
          break;
        }
      }
    //------------------------------------------------------------------------------------------------------------------------
    private DataTable ConnectToData(string connectionString, string i_command)
      {
      using (SqlConnection connection = new SqlConnection(connectionString))
        {
        SqlDataAdapter adapter = new SqlDataAdapter();
        adapter.TableMappings.Add("Table", "ClusterDiagnostics");
        connection.Open();

        SqlCommand command = new SqlCommand(i_command, connection);
        command.CommandType = CommandType.Text;

        adapter.SelectCommand = command;

        // Fill the DataSet.
        DataSet table = new DataSet();
        table.DataSetName = "DataSet1";
        adapter.Fill(table);
        return table.Tables[0];
        }
      }
    //-----------------------------------------------------------------------------------------------------------------------------------
    static private string GetConnectionString()
      {
      // To avoid storing the connection string in your code, 
      // you can retrieve it from a configuration file.
      return "Data Source=91.202.128.62;Initial Catalog=HPCDiagnostics;Integrated Security=True";
      }
    //-----------------------------------------------------------------------------------------------------------------------------------
    protected void UpdateGraphics_Click(object sender, EventArgs e)
      {
      DateTime start = (DateTime)DateStartCalendarExtender.SelectedDate;
      DateTime end = (DateTime)DateEndCalendarExtender.SelectedDate;
      Session["start time"] = new DateTime(start.Year, start.Month, start.Day,
                                           StartHour.SelectedIndex, StartMinute.SelectedIndex, 0);
      Session["end time"] = new DateTime(end.Year, end.Month, end.Day,
                                           EndHour.SelectedIndex, EndMinute.SelectedIndex, 0);

      end = ((DateTime)Session["end time"]);
      start = ((DateTime)Session["start time"]);
      _BuildReports(start, end);
      }
    //------------------------------------------------------------------------------------------------------------------------
    protected void UpdateStartDate_Click(object sender, EventArgs e)
      {
      char[] separator = new char[2];
      separator[0] = '-';
      separator[1] = '-';
      string[] start = DateStart.Text.Split(separator);
      DateStartCalendarExtender.SelectedDate = new DateTime(int.Parse(start[2]), int.Parse(start[1]), int.Parse(start[0]));
      }
    //------------------------------------------------------------------------------------------------------------------------
    protected void UpdateEndDate_Click(object sender, EventArgs e)
      {
      char[] separator = new char[2];
      separator[0] = '-';
      separator[1] = '-';
      string[] end = DateEnd.Text.Split(separator);
      DateEndCalendarExtender.SelectedDate = new DateTime(int.Parse(end[2]), int.Parse(end[1]), int.Parse(end[0]));
      }
    //------------------------------------------------------------------------------------------------------------------------
    [WebMethod(EnableSession = true)]
    protected void _CreateGraphicsDateTime(DateTime i_start_time, DateTime i_end_time)
      {
      if (Session["start time"] == null)
        Session["start time"] = i_start_time;
      if (Session["end time"] == null)
        Session["end time"] = i_end_time;
      }
    //------------------------------------------------------------------------------------------------------------------------
    private string _GetDateTimeForSQLQuery(DateTime date_time)
      {
      System.Text.StringBuilder builder = new System.Text.StringBuilder();
      builder.Append(date_time.Year);
      builder.Append("-");
      builder.Append(date_time.Month);
      builder.Append("-");
      builder.Append(date_time.Day);
      builder.Append(" ");
      builder.Append(date_time.Hour);
      builder.Append(":");
      builder.Append(date_time.Minute);
      builder.Append(":");
      builder.Append(date_time.Second);
      builder.Append(":");
      builder.Append(date_time.Millisecond);
      return builder.ToString();
      }
    //------------------------------------------------------------------------------------------------------------------------
    protected void TimeInterval_SelectedIndexChanged(object sender, EventArgs e)
      {
      string value = e.ToString();
      }
    //------------------------------------------------------------------------------------------------------------------------
    }
  }