﻿using System;
using System.Configuration;
using System.DirectoryServices;
using System.Web.Security;

/// <summary>
/// Summary description for CustomMembership
/// </summary>
namespace WebTaskManager
  {
  public class CustomMembership : MembershipProvider
    {
    public CustomMembership()
      {
      //
      // TODO: Add constructor logic here
      //
      }

    private string appName = "";
    public override string ApplicationName
      {
      get
        {
        return appName;
        }
      set
        {
        appName = value;
        }
      }

    public override bool ChangePassword(string username, string oldPassword, string newPassword)
      {
      throw new NotImplementedException();
      }

    public override bool ChangePasswordQuestionAndAnswer(string username, string password, string newPasswordQuestion, string newPasswordAnswer)
      {
      throw new NotImplementedException();
      }

    public override MembershipUser CreateUser(string username, string password, string email, string passwordQuestion, string passwordAnswer, bool isApproved, object providerUserKey, out MembershipCreateStatus status)
      {
      throw new NotImplementedException();
      }

    public override bool DeleteUser(string username, bool deleteAllRelatedData)
      {
      throw new NotImplementedException();
      }

    public override bool EnablePasswordReset
      {
      get { throw new NotImplementedException(); }
      }

    public override bool EnablePasswordRetrieval
      {
      get { throw new NotImplementedException(); }
      }

    public override MembershipUserCollection FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
      {
      throw new NotImplementedException();
      }

    public override MembershipUserCollection FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
      {
      throw new NotImplementedException();
      }

    public override MembershipUserCollection GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
      {
      throw new NotImplementedException();
      }

    public override int GetNumberOfUsersOnline()
      {
      throw new NotImplementedException();
      }

    public override string GetPassword(string username, string answer)
      {
      throw new NotImplementedException();
      }

    public override MembershipUser GetUser(string username, bool userIsOnline)
      {
      throw new NotImplementedException();
      }

    public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
      {
      throw new NotImplementedException();
      }

    public override string GetUserNameByEmail(string email)
      {
      throw new NotImplementedException();
      }

    public override int MaxInvalidPasswordAttempts
      {
      get { throw new NotImplementedException(); }
      }

    public override int MinRequiredNonAlphanumericCharacters
      {
      get { throw new NotImplementedException(); }
      }

    public override int MinRequiredPasswordLength
      {
      get { throw new NotImplementedException(); }
      }

    public override int PasswordAttemptWindow
      {
      get { throw new NotImplementedException(); }
      }

    public override MembershipPasswordFormat PasswordFormat
      {
      get { throw new NotImplementedException(); }
      }

    public override string PasswordStrengthRegularExpression
      {
      get { throw new NotImplementedException(); }
      }

    public override bool RequiresQuestionAndAnswer
      {
      get { throw new NotImplementedException(); }
      }

    public override bool RequiresUniqueEmail
      {
      get { throw new NotImplementedException(); }
      }

    public override string ResetPassword(string username, string answer)
      {
      throw new NotImplementedException();
      }

    public override bool UnlockUser(string userName)
      {
      throw new NotImplementedException();
      }

    public override void UpdateUser(MembershipUser user)
      {
      throw new NotImplementedException();
      }

    //------------------------------------------------------------------------------------------------------------------------
    public override bool ValidateUser(string username, string password)
      {
      DirectoryEntry de = _GetDirectoryEntry();
      de.Username = username;
      de.Password = password;

      DirectorySearcher deSearch = new DirectorySearcher();
      deSearch.SearchRoot = de;
      try
        {
        SearchResultCollection results = deSearch.FindAll();
        return results.Count > 0;
        }
      catch (System.DirectoryServices.DirectoryServicesCOMException)
        {
        return false;
        }
      }
    //------------------------------------------------------------------------------------------------------------------------
    protected static DirectoryEntry _GetDirectoryEntry()
      {
      DirectoryEntry de = new DirectoryEntry(_ldap_connection, _admin_username, _admin_password, AuthenticationTypes.Secure);
      return de;
      }
    //------------------------------------------------------------------------------------------------------------------------

    private static string _ldap_connection = ConfigurationSettings.AppSettings["ADConnectionString"];
    private static string _admin_username = ConfigurationSettings.AppSettings["ADusername"];
    private static string _admin_password = ConfigurationSettings.AppSettings["ADpassword"];

    }
  }