﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web;

namespace WebTaskManager.FileManager
{
  public class FileSystemItem
  {
    private string strName;
    private string strFullName;

    private DateTime dtCreationDate;
    private DateTime dtLastAccessDate;
    private DateTime dtLastWriteDate;

    private bool blnIsFolder;

    private long lngSize;
    private long lngFileCount;
    private long lngSubFolderCount;

    public string Name
    {
      get
      {
        return strName;
      }
      set
      {
        strName = value;
      }
    }

    public string FullName
    {
      get
      {
        return strFullName;
      }
      set
      {
        strFullName = value;
      }
    }

    public DateTime CreationDate
    {
      get
      {
        return dtCreationDate;
      }
      set
      {
        dtCreationDate = value;
      }
    }

    public bool IsFolder
    {
      get
      {
        return blnIsFolder;
      }
      set
      {
        blnIsFolder = value;
      }
    }

    public long Size
    {
      get
      {
        return lngSize;
      }
      set
      {
        lngSize = value;
      }
    }

    public DateTime LastAccessDate
    {
      get
      {
        return dtLastAccessDate;
      }
      set
      {
        dtLastAccessDate = value;
      }
    }

    public DateTime LastWriteDate
    {
      get
      {
        return dtLastWriteDate;
      }
      set
      {
        dtLastWriteDate = value;
      }
    }

    public long FileCount
    {
      get
      {
        return lngFileCount;
      }
      set
      {
        lngFileCount = value;
      }
    }

    public long SubFolderCount
    {
      get
      {
        return lngSubFolderCount;
      }
      set
      {
        lngSubFolderCount = value;
      }
    }
  }
  public class FileSystemManager
  {
    private static string strRootFolder;
    private static string uploadFolder;

    static FileSystemManager()
    {
    }

    public static string GetRootPath()
    {
      return strRootFolder;
    }

    public static void SetRootPath(string path)
    {
      strRootFolder = path;
    }

    public static string UploadFolder
    {
      get { return uploadFolder; }
      set { uploadFolder = value; }
    }

    public static List<FileSystemItem> GetItems()
    {
      return GetItems(strRootFolder);
    }

    public static List<FileSystemItem> GetItems(string path)
    {
      string[] folders = Directory.GetDirectories(path);
      string[] files = Directory.GetFiles(path);
      List<FileSystemItem> list = new List<FileSystemItem>();
      foreach (string s in folders)
      {
        FileSystemItem item = new FileSystemItem();
        DirectoryInfo di = new DirectoryInfo(s);
        item.Name = di.Name;
        item.FullName = di.FullName;
        item.CreationDate = di.CreationTime;
        item.LastWriteDate = di.LastWriteTime;
        item.IsFolder = true;
        list.Add(item);
      }
      foreach (string s in files)
      {
        FileSystemItem item = new FileSystemItem();
        FileInfo fi = new FileInfo(s);
        item.Name = fi.Name;
        item.FullName = fi.FullName;
        item.CreationDate = fi.CreationTime;
        item.LastWriteDate = fi.LastWriteTime;
        item.IsFolder = true;
        item.Size = fi.Length;
        list.Add(item);
      }

      if (path.ToLower() != strRootFolder.ToLower())
      {
        FileSystemItem topitem = new FileSystemItem();
        DirectoryInfo topdi = new DirectoryInfo(path).Parent;
        topitem.Name = "[Parent]";
        topitem.FullName = topdi.FullName;
        list.Insert(0, topitem);

        FileSystemItem rootitem = new FileSystemItem();
        DirectoryInfo rootdi = new DirectoryInfo(strRootFolder);
        rootitem.Name = "[Root]";
        rootitem.FullName = rootdi.FullName;
        list.Insert(0, rootitem);

      }
      if (list.Count > 0)
        return list;
      else
      {
        FileSystemItem item = new FileSystemItem();
        DirectoryInfo rootdir = new DirectoryInfo(strRootFolder);
        item.Name = "Папка порожня";
        item.FullName = rootdir.FullName;
        item.CreationDate = rootdir.CreationTime;
        item.LastWriteDate = rootdir.LastWriteTime;
        item.IsFolder = true;
        list.Add(item);
        return list;
      }
    }

    public static void CreateFolder(string name, string parentName)
    {
      DirectoryInfo di = new DirectoryInfo(parentName);
      di.CreateSubdirectory(name);
    }

    public static void DeleteFolder(string path)
    {
      Directory.Delete(path, true);
    }

    public static void MoveFolder(string oldPath, string newPath)
    {
      Directory.Move(oldPath, newPath);
    }

    public static void CreateFile(string filename, string path)
    {
      FileStream fs = File.Create(path + "\\" + filename);
      fs.Close();
    }

    public static void CreateFile(string filename, string path, byte[] contents)
    {
      FileStream fs = File.Create(path + "\\" + filename);
      fs.Write(contents, 0, contents.Length);
      fs.Close();
    }

    public static void DeleteFile(string path)
    {
      File.Delete(path);
    }

    public static void MoveFile(string oldPath, string newPath)
    {
      File.Move(oldPath, newPath);
    }

    public static FileSystemItem GetItemInfo(string path)
    {
      FileSystemItem item = new FileSystemItem();
      if (Directory.Exists(path))
      {
        DirectoryInfo di = new DirectoryInfo(path);
        item.Name = di.Name;
        item.FullName = di.FullName;
        item.CreationDate = di.CreationTime;
        item.IsFolder = true;
        item.LastAccessDate = di.LastAccessTime;
        item.LastWriteDate = di.LastWriteTime;
        item.FileCount = di.GetFiles().Length;
        item.SubFolderCount = di.GetDirectories().Length;
      }
      else
      {
        FileInfo fi = new FileInfo(path);
        item.Name = fi.Name;
        item.FullName = fi.FullName;
        item.CreationDate = fi.CreationTime;
        item.LastAccessDate = fi.LastAccessTime;
        item.LastWriteDate = fi.LastWriteTime;
        item.IsFolder = false;
        item.Size = fi.Length;
      }
      return item;
    }

    public static void CopyFolder(string source, string destination)
    {
      String[] files;
      if (destination[destination.Length - 1] != Path.DirectorySeparatorChar)
        destination += Path.DirectorySeparatorChar;
      if (!Directory.Exists(destination)) Directory.CreateDirectory(destination);
      files = Directory.GetFileSystemEntries(source);
      foreach (string element in files)
      {
        if (Directory.Exists(element))
          CopyFolder(element, destination + Path.GetFileName(element));
        else
          File.Copy(element, destination + Path.GetFileName(element), true);
      }
    }

    public static List<FileSystemItem> GetAllFiles(string folderName)
    {
      if (Directory.Exists(folderName))
      {
        List<FileSystemItem> items = new List<FileSystemItem>();
        FileSystemItem item;
        FileInfo fi;
        foreach (string fileName in Directory.GetFiles(folderName, "*", SearchOption.AllDirectories))
        {
          fi = new FileInfo(fileName);
          item = new FileSystemItem();
          item.Name = fi.Name;
          item.FullName = fi.FullName;
          item.CreationDate = fi.CreationTime;
          item.LastAccessDate = fi.LastAccessTime;
          item.LastWriteDate = fi.LastWriteTime;
          item.IsFolder = false;
          item.Size = fi.Length;
          items.Add(item);
        }
        return items;
      }
      return null;
    }
  }

}