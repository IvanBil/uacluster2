﻿<script language="javascript" type="text/javascript">
    var FileManager;

    function pageLoad() {
        FileManager = new BinaryIntellect.Web.UI.FileManager();

        var obj = document.getElementById('ctl00_ContentPlaceHolder1_Panel5');
        obj.style.visibility = "hidden";
    }
</script>

<div>
<!-- FileManager Class Begin -->
<script type="text/javascript">

    Type.registerNamespace("BinaryIntellect.Web.UI");

    BinaryIntellect.Web.UI.FileManager = function() {
        this._x;
        this._y;
    }

    BinaryIntellect.Web.UI.FileManager.prototype =
{
    GetMouseX: function() {
        return this._x;
    },

    SetMouseX: function(value) {
        this._x = value;
    },

    GetMouseY: function() {
        return this._y;
    },

    SetMouseY: function(value) {
        this._y = value;
    },

    ShowContextMenu: function(evt) {
        var obj = document.getElementById('ctl00_ContentPlaceHolder1_Panel5');
        obj.style.visibility = "visible";
        obj.style.position = "absolute";
        if (evt.x) {
            obj.style.posLeft = event.x;
            obj.style.posTop = event.y;
        }
        else {
            obj.style.left = evt.layerX + "px";
            obj.style.top = evt.layerY + "px";
        }
        return false;
    },

    HideContextMenu: function() {
        var obj = document.getElementById('ctl00_ContentPlaceHolder1_Panel5');
        obj.style.visibility = "hidden";
        return false;
    },

    ClickButton: function(srcElement) {
        FileManager.HideContextMenu();
        document.getElementById(srcElement).click();
        return false;
    },

    ToggleSelectionForAllItems: function(evt) {
        var count = 0;
        var items = document.form1.getElementsByTagName("input");
        for (i = 0; i < items.length; i++) {
            if (items[i].type == "checkbox") {
                if (evt.srcElement) {
                    if (items[i].id != evt.srcElement.id) {
                        items[i].checked = evt.srcElement.checked;
                        count++;
                    }
                }
                else {
                    if (items[i].id != evt.target.id) {
                        items[i].checked = evt.target.checked;
                        count++;
                    }
                }
            }
        }
    },

    UnselectHeaderCheckBox: function(evt) {
        if (evt.srcElement) {
            if (event.srcElement.checked == false) {
                var count = 0;
                var items = document.form1.getElementsByTagName("input");
                for (i = 0; i < items.length; i++) {
                    if (items[i].type == "checkbox") {
                        if (items[i].id.indexOf('chkHeader') > 0) {
                            items[i].checked = false;
                        }
                    }
                }
            }
        }
        else {
            if (evt.target.checked == false) {
                var count = 0;
                var items = document.form1.getElementsByTagName("input");
                for (i = 0; i < items.length; i++) {
                    if (items[i].type == "checkbox") {
                        if (items[i].id.indexOf('chkHeader') > 0) {
                            items[i].checked = false;
                        }
                    }
                }
            }
        }
    },

    OnError: function(result) {
        if (result.get_exceptionType() == "System.IO.FileNotFoundException") {
            //do nothing    
        }
        else {
            alert(result.get_message());
        }

    },

    GetSelectedItemCount: function() {
        var count = 0;
        var items = document.form1.getElementsByTagName("input");
        for (i = 0; i < items.length; i++) {
            if (items[i].type == "checkbox") {
                if (items[i].checked) {
                    count++;
                }
            }
        }
        return count;
    },

    Rename: function() {
        if (document.getElementById('TextBox3').value == "") {
            alert("Please enter new name!");
            return false;
        }
        var count = 0;
        count = FileManager.GetSelectedItemCount();
        if (count == 0) {
            alert("Please select an item to rename");
            return false;
        }
        if (count > 1) {
            alert("Please select only one item to rename");
            return false;
        }
        else {
            __doPostBack('btnRename', '');
        }
    },

    Cut: function() {
        var count = 0;
        var items = document.form1.getElementsByTagName("input");
        count = FileManager.GetSelectedItemCount();
        if (count == 0) {
            alert("Please select an item to cut");
            return false;
        }
        else {
            __doPostBack('btnRename', '');
        }
    },

    Paste: function() {
        __doPostBack('btnPaste', '');
    },

    Copy: function() {
        var count = 0;
        var items = document.form1.getElementsByTagName("input");
        count = FileManager.GetSelectedItemCount();
        if (count == 0) {
            alert("Please select an item to copy");
            return false;
        }
        else {
            __doPostBack('btnCopy', '');
        }
    },

    Create: function() {
        if (document.getElementById('TextBox2').value == "") {
            alert("Please enter folder name!");
            return false;
        }
        else {
            __doPostBack('btnCreate', '');
        }
    },

    Delete: function() {
    var count = 0;
        var items = document.form1.getElementsByTagName("input");
        count = FileManager.GetSelectedItemCount();
        if (count == 0) {
            alert("Please select items to delete");
            return false;
        }
        else {
            __doPostBack('btnDelete', '')
        }
    },

    Upload: function() {
        if (document.getElementById('FileUpload1').value == "") {
            alert("Please select file to upload!");
            return false;
        }
        else {
            __doPostBack('btnUpload', '');
        }
    }
}

    BinaryIntellect.Web.UI.FileManager.registerClass('BinaryIntellect.Web.UI.FileManager', null, Sys.IDisposable);

</script>
