﻿using System;
using System.Web.Security;

namespace WebTaskManager
  {
  public partial class _Default : System.Web.UI.Page
    {
    protected void Page_Load(object sender, EventArgs e)
      {
        if (!User.Identity.IsAuthenticated)
        {
          FormsAuthentication.RedirectToLoginPage();
          return;
        }
      }
    }
  }
